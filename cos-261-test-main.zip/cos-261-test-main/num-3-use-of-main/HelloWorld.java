/*
 * The main method in Java is the entry point of any standalone Java application.
 * It tells the Java Virtual Machine (JVM) where to begin execution of your program.
 * */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}

